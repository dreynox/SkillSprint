const API_BASE = window.API_BASE_URL || "http://127.0.0.1:8000";

function getToken() {
    const raw = localStorage.getItem("access_token") || localStorage.getItem("token") || "";
    const cleaned = String(raw).trim().replace(/^"|"$/g, "");
    if (!cleaned || cleaned === "undefined" || cleaned === "null") {
        return "";
    }
    return cleaned;
}

function authHeaders() {
    const token = getToken();
    return token ? { Authorization: `Bearer ${token}` } : {};
}

let currentChatUserId = null;
let currentChatUserName = null;
let voiceStream = null;
let mediaRecorder = null;
let callActive = false;
let callStartTime = null;
let isMuted = false;
let conversationByUserId = new Map();
let userSearchDebounce = null;
let currentUserProfile = null;
let premiumPlanData = null;
let pendingUndo = null;

document.addEventListener('DOMContentLoaded', async () => {
    const chatForm = document.getElementById('chat-form');
    const msgInput = document.getElementById('msg-input');
    const fileBtn = document.getElementById('file-btn');
    const fileInput = document.getElementById('file-input');
    const newChatBtn = document.getElementById('new-chat-btn');
    const voiceCallBtn = document.getElementById('voice-call-btn');
    const endCallBtn = document.getElementById('end-call-btn');
    const closeVoiceModal = document.getElementById('close-voice-modal');
    const emojiBtn = document.getElementById('emoji-btn');
    const muteBtn = document.getElementById('mute-btn');
    const userSearchInput = document.getElementById('user-search-input');
    const openPremiumModalBtn = document.getElementById('open-premium-modal');
    const closePremiumModalBtn = document.getElementById('close-premium-modal');
    const buyPremiumBtn = document.getElementById('buy-premium-btn');
    const mobileConversationsBtn = document.getElementById('mobile-conversations-btn');

    currentUserProfile = await loadCurrentUserProfile();
    await loadPremiumPlans();
    updateRetentionBanner();

    // Load conversations on page load
    const conversations = await loadConversations();
    await maybeAutoOpenSelectedRecipient(conversations || []);

    // If no preselected recipient, open the latest conversation automatically.
    if (!currentChatUserId && Array.isArray(conversations) && conversations.length > 0) {
        const first = conversations[0];
        await selectConversation(Number(first.user_id), first.name || `User ${first.user_id}`);
    }

    // Send message
    chatForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const message = msgInput.value.trim();

        if (!message && !currentChatUserId) {
            alert('Please select a user to chat with');
            return;
        }

        if (message && currentChatUserId) {
            try {
                const response = await fetch(`${API_BASE}/messages/send`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        ...authHeaders(),
                    },
                    body: JSON.stringify({
                        recipient_id: currentChatUserId,
                        content: message,
                        media_type: 'text',
                    }),
                });

                if (response.ok) {
                    msgInput.value = '';
                    await loadMessages(currentChatUserId);
                    await loadConversations();
                }
            } catch (error) {
                console.error('Error sending message:', error);
            }
        }
    });

    // File upload
    fileBtn.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', async (e) => {
        if (!currentChatUserId) {
            alert('Please select a user first');
            return;
        }

        const file = e.target.files[0];
        if (file) {
            await uploadMedia(file, currentChatUserId, detectMediaType(file));
        }
        fileInput.value = '';
    });

    // New chat
    newChatBtn.addEventListener('click', openUserSelectionModal);

    // Quick emoji insert
    emojiBtn.addEventListener('click', () => {
        msgInput.value += '😊';
        msgInput.focus();
    });

    // Voice call
    voiceCallBtn.addEventListener('click', () => {
        if (currentChatUserId) {
            startVoiceCall();
        } else {
            alert('Please select a user first');
        }
    });

    // End call
    endCallBtn.addEventListener('click', endVoiceCall);

    // Mute/unmute local mic during recording
    muteBtn.addEventListener('click', toggleMute);

    // Close modals
    closeVoiceModal.addEventListener('click', () => {
        document.getElementById('voice-modal').style.display = 'none';
    });

    document.getElementById('close-user-modal').addEventListener('click', () => {
        document.getElementById('user-modal').style.display = 'none';
    });

    if (openPremiumModalBtn) {
        openPremiumModalBtn.addEventListener('click', openPremiumModal);
    }

    if (closePremiumModalBtn) {
        closePremiumModalBtn.addEventListener('click', () => {
            document.getElementById('premium-modal').style.display = 'none';
        });
    }

    if (buyPremiumBtn) {
        buyPremiumBtn.addEventListener('click', buyPremiumPlan);
    }

    if (mobileConversationsBtn) {
        mobileConversationsBtn.addEventListener('click', () => {
            document.getElementById('chat-wrapper')?.classList.toggle('show-conversations');
        });
    }

    document.addEventListener('keydown', (event) => {
        if (event.key !== 'Escape') {
            return;
        }
        document.getElementById('voice-modal').style.display = 'none';
        document.getElementById('user-modal').style.display = 'none';
        document.getElementById('premium-modal').style.display = 'none';
        document.getElementById('chat-wrapper')?.classList.remove('show-conversations');
    });

    if (userSearchInput) {
        userSearchInput.addEventListener('input', () => {
            const query = userSearchInput.value.trim();
            clearTimeout(userSearchDebounce);
            userSearchDebounce = setTimeout(() => {
                searchUsersForChat(query);
            }, 220);
        });

        userSearchInput.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') {
                event.preventDefault();
                const first = document.querySelector('#users-list .user-item');
                if (first) {
                    first.click();
                }
            }
        });
    }

    // Auto-refresh messages every 2 seconds
    setInterval(() => {
        if (currentChatUserId) {
            loadMessages(currentChatUserId, true);
            loadConversations();
        }
    }, 2000);
});

async function loadConversations() {
    try {
        const response = await fetch(`${API_BASE}/messages/conversations`, {
            headers: authHeaders(),
        });

        if (!response.ok) throw new Error('Failed to load conversations');

        const conversations = await response.json();
        renderConversations(conversations);
        return conversations;
    } catch (error) {
        console.error('Error loading conversations:', error);
        return [];
    }
}

async function maybeAutoOpenSelectedRecipient(conversations) {
    const selectedRecipientIdRaw = sessionStorage.getItem('selectedRecipientId');
    if (!selectedRecipientIdRaw) {
        return;
    }

    sessionStorage.removeItem('selectedRecipientId');
    const selectedRecipientId = Number(selectedRecipientIdRaw);
    if (!Number.isFinite(selectedRecipientId)) {
        return;
    }

    const existingConversation = conversations.find((conv) => conv.user_id === selectedRecipientId);
    if (existingConversation) {
        await selectConversation(existingConversation.user_id, existingConversation.name);
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/users/${selectedRecipientId}`, {
            headers: authHeaders(),
        });
        if (!response.ok) {
            throw new Error('Recipient not found');
        }

        const user = await response.json();
        await selectConversation(user.id, user.name || `User ${user.id}`);

        // Ensure the user picker is hidden when arriving from profile->message flow.
        const userModal = document.getElementById('user-modal');
        if (userModal) {
            userModal.style.display = 'none';
        }
    } catch (error) {
        console.error('Could not auto-open selected recipient:', error);
    }
}

function renderConversations(conversations) {
    const conversationsList = document.getElementById('conversations-list');
    conversationByUserId = new Map((conversations || []).map((conv) => [Number(conv.user_id), conv]));

    if (conversations.length === 0) {
        conversationsList.innerHTML = '<div class="placeholder">No conversations yet</div>';
        return;
    }

    conversationsList.innerHTML = '';
    conversations.forEach((conv) => {
        const convDiv = document.createElement('div');
        convDiv.className = 'conversation-item';
        if (conv.user_id === currentChatUserId) convDiv.classList.add('active');

        const unreadBadge = conv.unread_count > 0 ? `<span class="unread-badge">${conv.unread_count}</span>` : '';

        convDiv.innerHTML = `
            <div class="conversation-avatar">
                ${conv.avatar_url ? `<img src="${conv.avatar_url}" alt="${conv.name}">` : '<div class="avatar-placeholder">' + conv.name[0].toUpperCase() + '</div>'}
            </div>
            <div class="conversation-info">
                <h4>${conv.name}</h4>
                <p>${conv.last_message}</p>
            </div>
            <div class="conversation-meta">
                <small>${formatTime(conv.last_message_time)}</small>
                ${unreadBadge}
            </div>
        `;

        convDiv.addEventListener('dblclick', () => {
            window.location.href = `profile.html?user_id=${conv.user_id}`;
        });

        convDiv.addEventListener('click', (event) => selectConversation(conv.user_id, conv.name, event));
        conversationsList.appendChild(convDiv);
    });
}

async function selectConversation(userId, userName, clickEvent = null) {
    currentChatUserId = Number(userId);
    currentChatUserName = userName;

    // Update active conversation
    document.querySelectorAll('.conversation-item').forEach((el) => el.classList.remove('active'));
    const activeConversation = clickEvent?.target?.closest('.conversation-item');
    if (activeConversation) {
        activeConversation.classList.add('active');
    }

    // Show chat area
    document.getElementById('chat-empty').style.display = 'none';
    document.getElementById('chat-area').style.display = 'flex';

    // Update header
    document.getElementById('chat-user-name').textContent = userName;

    // Load messages
    await loadMessages(userId);
}

async function loadMessages(userId, silent = false) {
    try {
        const response = await fetch(`${API_BASE}/messages/with/${userId}`, {
            headers: authHeaders(),
        });

        if (!response.ok) {
            let detail = 'Failed to load messages';
            try {
                const errData = await response.json();
                detail = errData?.detail || `${detail} (${response.status})`;
            } catch (_err) {
                detail = `${detail} (${response.status})`;
            }
            throw new Error(detail);
        }

        const data = await response.json();
        const messages = Array.isArray(data) ? data : (Array.isArray(data?.messages) ? data.messages : []);

        if (!silent) {
            renderMessages(messages);
        } else {
            // Only update if there are new messages
            const currentMessages = document.querySelectorAll('.message').length;
            if (messages.length > currentMessages) {
                renderMessages(messages);
            }
        }
    } catch (error) {
        console.error('Error loading messages:', error);
        if (!silent) {
            const messageArena = document.getElementById('message-display');
            if (messageArena) {
                messageArena.innerHTML = `<div class="placeholder" style="color:#ff8484;">${escapeHtml(error?.message || 'Failed to load messages')}</div>`;
            }
        }
    }
}

function renderMessages(messages) {
    const messageArena = document.getElementById('message-display');
    
    // Get current user ID
    const currentUserData = JSON.parse(localStorage.getItem('user') || '{}');
    const currentUserId = currentUserData.id;

    messageArena.innerHTML = '';

    if (messages.length === 0) {
        messageArena.innerHTML = '<div class="placeholder">No messages yet. Start the conversation!</div>';
        return;
    }

    messages.forEach((msg) => {
        const isOutgoing = msg.sender_id === currentUserId;
        const msgDiv = document.createElement('div');
        msgDiv.className = `message ${isOutgoing ? 'outgoing' : 'incoming'}`;

        const time = msg.created_at
            ? parseServerDate(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            : '';
        let bubbleContent = '';

        if (msg.media_type === 'text') {
            bubbleContent = `<p>${escapeHtml(msg.content || '')}</p>`;
        } else if (msg.media_type === 'image') {
            bubbleContent = `<img src="${normalizeMediaUrl(msg.file_path)}" alt="image" class="media-preview">`;
        } else if (msg.media_type === 'video') {
            bubbleContent = `<video controls class="media-preview"><source src="${normalizeMediaUrl(msg.file_path)}"></video>`;
        } else if (msg.media_type === 'voice') {
            bubbleContent = `<audio controls><source src="${normalizeMediaUrl(msg.file_path)}"></audio>`;
        } else if (msg.media_type === 'file') {
            bubbleContent = `<a href="${normalizeMediaUrl(msg.file_path)}" download class="file-link">📄 ${msg.content}</a>`;
        } else {
            bubbleContent = `<p>${msg.content || 'Unknown media'}</p>`;
        }

        msgDiv.innerHTML = `
            <div class="bubble">
                ${!isOutgoing ? `<span class="ref-tag">REF: ${escapeHtml(currentChatUserName || 'User')}</span>` : ''}
                ${bubbleContent}
                <span class="timestamp">${time}</span>
            </div>
        `;

        messageArena.appendChild(msgDiv);
    });

    messageArena.scrollTop = messageArena.scrollHeight;
}

async function uploadMedia(file, recipientId, mediaType) {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('media_type', mediaType);

    try {
        document.getElementById('upload-progress').style.display = 'block';

        const response = await fetch(
            `${API_BASE}/messages/upload/${recipientId}`,
            {
                method: 'POST',
                headers: authHeaders(),
                body: formData,
            }
        );

        if (response.ok) {
            document.getElementById('upload-progress').style.display = 'none';
            await loadMessages(recipientId);
            await loadConversations();
        } else {
            throw new Error('Upload failed');
        }
    } catch (error) {
        console.error('Error uploading media:', error);
        alert('Failed to upload file');
        document.getElementById('upload-progress').style.display = 'none';
    }
}

function detectMediaType(file) {
    const type = file.type;
    if (type.startsWith('image/')) return 'image';
    if (type.startsWith('video/')) return 'video';
    if (type.startsWith('audio/')) return 'voice';
    return 'file';
}

async function startVoiceCall() {
    try {
        voiceStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        callActive = true;
        callStartTime = Date.now();
        isMuted = false;

        document.getElementById('voice-modal').style.display = 'flex';
        document.getElementById('voice-call-user').textContent = currentChatUserName;
        document.getElementById('mute-btn').textContent = 'Mute';

        // Start recording
        mediaRecorder = new MediaRecorder(voiceStream);
        const audioChunks = [];

        mediaRecorder.ondataavailable = (e) => {
            audioChunks.push(e.data);
        };

        mediaRecorder.onstop = async () => {
            const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
            const formData = new FormData();
            formData.append('file', new File([audioBlob], 'voice_message.wav'));
            formData.append('media_type', 'voice');

            try {
                const response = await fetch(
                    `${API_BASE}/messages/upload/${currentChatUserId}`,
                    {
                        method: 'POST',
                        headers: authHeaders(),
                        body: formData,
                    }
                );

                if (response.ok) {
                    await loadMessages(currentChatUserId);
                    await loadConversations();
                }
            } catch (error) {
                console.error('Error sending voice message:', error);
            }
        };

        mediaRecorder.start();

        // Update call duration
        const durationInterval = setInterval(() => {
            if (!callActive) {
                clearInterval(durationInterval);
                return;
            }
            const elapsed = Math.floor((Date.now() - callStartTime) / 1000);
            const minutes = Math.floor(elapsed / 60);
            const seconds = elapsed % 60;
            document.getElementById('call-duration').textContent = 
                `${minutes}:${seconds.toString().padStart(2, '0')}`;
        }, 1000);
    } catch (error) {
        console.error('Error starting voice call:', error);
        alert('Could not access microphone');
    }
}

function endVoiceCall() {
    if (mediaRecorder) {
        mediaRecorder.stop();
    }

    if (voiceStream) {
        voiceStream.getTracks().forEach((track) => track.stop());
    }

    callActive = false;
    isMuted = false;
    document.getElementById('voice-modal').style.display = 'none';
    document.getElementById('mute-btn').textContent = 'Mute';
}

function toggleMute() {
    if (!voiceStream) {
        return;
    }

    isMuted = !isMuted;
    voiceStream.getAudioTracks().forEach((track) => {
        track.enabled = !isMuted;
    });

    document.getElementById('mute-btn').textContent = isMuted ? 'Unmute' : 'Mute';
}

async function openUserSelectionModal() {
    document.getElementById('user-modal').style.display = 'flex';
    const usersList = document.getElementById('users-list');
    const userSearchInput = document.getElementById('user-search-input');

    if (usersList) {
        usersList.innerHTML = '<div class="placeholder">Type at least 2 letters to find people.</div>';
    }

    if (userSearchInput) {
        userSearchInput.value = '';
        userSearchInput.focus();
    }
}

async function searchUsersForChat(query) {
    const usersList = document.getElementById('users-list');
    if (!usersList) {
        return;
    }

    if (!query || query.length < 2) {
        usersList.innerHTML = '<div class="placeholder">Type at least 2 letters to find people.</div>';
        return;
    }

    usersList.innerHTML = '<div class="placeholder">Searching...</div>';

    try {
        const response = await fetch(`${API_BASE}/users/search?q=${encodeURIComponent(query)}`, {
            headers: authHeaders(),
        });

        if (!response.ok) {
            throw new Error(`Search failed (${response.status})`);
        }

        const results = await response.json();
        const users = (Array.isArray(results) ? results : [])
            .filter((item) => item.type === 'user')
            .map((item) => ({
                id: item.id,
                name: item.name || `User ${item.id}`,
                email: item.email || '',
                avatar_url: item.avatar_url || null,
            }));

        renderUsersList(users);
    } catch (error) {
        console.error('Error searching users:', error);
        usersList.innerHTML = '<div class="placeholder">Search is unavailable right now.</div>';
    }
}

function renderUsersList(users) {
    const usersList = document.getElementById('users-list');
    usersList.innerHTML = '';

    const currentUser = JSON.parse(localStorage.getItem('user') || '{}');

    users.forEach((user) => {
        if (user.id === currentUser.id) return; // Skip self

        const userDiv = document.createElement('div');
        userDiv.className = 'user-item';

        userDiv.innerHTML = `
            <div class="user-avatar">
                ${user.avatar_url ? `<img src="${normalizeMediaUrl(user.avatar_url)}" alt="${user.name}">` : '<div class="avatar-placeholder">' + user.name[0].toUpperCase() + '</div>'}
            </div>
            <div class="user-info">
                <h4>${user.name}</h4>
                <p>${user.email}</p>
            </div>
        `;

        userDiv.addEventListener('click', (event) => {
            selectConversation(user.id, user.name, event);
            document.getElementById('user-modal').style.display = 'none';
            loadConversations();
        });

        userDiv.addEventListener('dblclick', () => {
            window.location.href = `profile.html?user_id=${user.id}`;
        });

        usersList.appendChild(userDiv);
    });
}

function formatTime(isoString) {
    const date = parseServerDate(isoString);
    const now = new Date();
    const diffMs = Math.max(0, now - date);
    const diffMins = Math.floor(diffMs / 60000);

    if (diffMins < 1) return 'now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)}h ago`;
    if (diffMins < 10080) return `${Math.floor(diffMins / 1440)}d ago`;

    return date.toLocaleDateString();
}

function parseServerDate(value) {
    const raw = String(value || '').trim();
    if (!raw) {
        return new Date();
    }

    // Backend emits naive UTC timestamps (no timezone suffix). Treat them as UTC.
    const hasTimezone = /(?:Z|[+-]\d{2}:?\d{2})$/i.test(raw);
    const normalized = hasTimezone ? raw : `${raw}Z`;
    const date = new Date(normalized);
    return Number.isNaN(date.getTime()) ? new Date() : date;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function normalizeMediaUrl(path) {
    if (!path) {
        return '';
    }

    if (/^https?:\/\//i.test(path)) {
        return path;
    }

    if (path.startsWith('/')) {
        return `${API_BASE}${path}`;
    }

    return `${API_BASE}/${path}`;
}

async function loadCurrentUserProfile() {
    try {
        const response = await fetch(`${API_BASE}/users/me`, {
            headers: authHeaders(),
        });

        if (!response.ok) {
            return JSON.parse(localStorage.getItem('user') || '{}');
        }

        const user = await response.json();
        if (user && user.id) {
            localStorage.setItem('user', JSON.stringify(user));
        }
        return user;
    } catch (error) {
        console.error('Error loading current user profile:', error);
        return JSON.parse(localStorage.getItem('user') || '{}');
    }
}

async function loadPremiumPlans() {
    try {
        const response = await fetch(`${API_BASE}/messages/premium/plans`, {
            headers: authHeaders(),
        });
        if (!response.ok) {
            throw new Error('Failed to load premium plan details');
        }
        premiumPlanData = await response.json();
    } catch (error) {
        console.error('Error loading premium plan details:', error);
        premiumPlanData = null;
    }
}

function isPremiumUser(user) {
    if (!user || !user.is_premium) {
        return false;
    }

    if (!user.premium_expires_at) {
        return true;
    }

    return parseServerDate(user.premium_expires_at) > new Date();
}

function updateRetentionBanner() {
    const planName = document.getElementById('plan-name');
    const retentionText = document.getElementById('retention-text');
    const premiumBtn = document.getElementById('open-premium-modal');
    const isPremium = isPremiumUser(currentUserProfile);

    if (!planName || !retentionText || !premiumBtn) {
        return;
    }

    if (isPremium) {
        planName.textContent = 'Premium Plan';
        retentionText.textContent = 'Your messages are stored forever.';
        premiumBtn.textContent = 'Manage Plan';
    } else {
        const hours = premiumPlanData?.retention_hours_free || 24;
        planName.textContent = 'Free Plan';
        retentionText.textContent = `Messages auto-delete after ${hours} hours.`;
        premiumBtn.textContent = 'Buy Premium';
    }
}

function openPremiumModal() {
    const modal = document.getElementById('premium-modal');
    if (!modal) {
        return;
    }

    renderPremiumComparison();
    modal.style.display = 'flex';
}

function renderPremiumComparison() {
    const host = document.getElementById('premium-comparison');
    if (!host) {
        return;
    }

    const currency = premiumPlanData?.currency || 'INR';
    const price = premiumPlanData?.premium?.price_monthly ?? 99;

    host.innerHTML = `
        <table class="premium-table">
            <thead>
                <tr>
                    <th>Feature</th>
                    <th>Free</th>
                    <th>Premium (${currency} ${price}/month)</th>
                </tr>
            </thead>
            <tbody>
                <tr><td>Message retention</td><td>24 hours</td><td>Forever</td></tr>
                <tr><td>Media uploads</td><td>Yes</td><td>Yes + priority delivery</td></tr>
                <tr><td>Pinned conversations</td><td>No</td><td>Up to 20 pins</td></tr>
                <tr><td>Message search</td><td>No</td><td>Full history search</td></tr>
                <tr><td>Read insights</td><td>Basic read status</td><td>Read time analytics</td></tr>
                <tr><td>Support</td><td>Standard</td><td>Priority support</td></tr>
            </tbody>
        </table>
    `;
}

async function buyPremiumPlan() {
    try {
        const response = await fetch(`${API_BASE}/messages/premium/activate?months=1`, {
            method: 'POST',
            headers: authHeaders(),
        });

        const data = await response.json();
        if (!response.ok) {
            throw new Error(data?.detail || 'Could not activate premium');
        }

        currentUserProfile = {
            ...(currentUserProfile || {}),
            is_premium: Boolean(data.is_premium),
            premium_expires_at: data.premium_expires_at || null,
        };
        localStorage.setItem('user', JSON.stringify(currentUserProfile));

        updateRetentionBanner();
        alert(`Premium activated for 1 month (INR ${data.price_paid_inr}).`);
        document.getElementById('premium-modal').style.display = 'none';
    } catch (error) {
        console.error('Error activating premium:', error);
        alert(error?.message || 'Premium activation failed');
    }
}